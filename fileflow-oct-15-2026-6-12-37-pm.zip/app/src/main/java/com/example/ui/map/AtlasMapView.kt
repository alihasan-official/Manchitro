package com.example.ui.map

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FriendshipEntity
import com.example.data.local.RouteEntity
import com.example.model.AvatarCatalog
import com.example.model.User
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun AtlasMapView(
    cameraLat: Double,
    cameraLng: Double,
    zoomLevel: Float,
    mapStyle: String,
    currentUser: User?,
    isSharingLocation: Boolean,
    friends: List<FriendshipEntity>,
    activeRoutes: List<RouteEntity>,
    selectedFriend: FriendshipEntity?,
    onFriendTapped: (FriendshipEntity) -> Unit,
    onMapPan: (dLat: Double, dLng: Double) -> Unit,
    onMapZoom: (zoomDelta: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Pulse animation for live markers
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    // Palette based on map style
    val isDark = mapStyle == "MIDNIGHT"
    val bgColor = if (isDark) AtlasBgDark else AtlasBgLight
    val roadColor = if (isDark) MapRoadDark else MapRoadLight
    val highwayColor = if (isDark) Color(0xFF2E3933) else Color(0xFFFFFFFF)
    val highwayCasing = if (isDark) Color(0xFF1E2823) else Color(0xFFE2E7E2)
    val waterColor = if (isDark) MapWaterDark else MapWaterLight
    val parkColor = if (isDark) MapParkDark else MapParkLight
    val textPrimary = if (isDark) AtlasTextPrimaryDark else AtlasTextPrimaryLight
    val textSecondary = if (isDark) AtlasTextSecondaryDark else AtlasTextSecondaryLight

    val friendScreenPositions = remember { mutableStateMapOf<String, Offset>() }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val scaleFactor = 0.000008 / (zoomLevel / 14f)
                    val dLat = (pan.y * scaleFactor).toDouble()
                    val dLng = (-pan.x * scaleFactor).toDouble()
                    onMapPan(dLat, dLng)
                    if (zoom != 1f) {
                        onMapZoom(zoom)
                    }
                }
            }
            .pointerInput(friends, friendScreenPositions) {
                detectTapGestures { tapOffset ->
                    var found: FriendshipEntity? = null
                    for (friend in friends) {
                        val pos = friendScreenPositions[friend.id]
                        if (pos != null) {
                            val dist = (pos - tapOffset).getDistance()
                            if (dist < 80f) {
                                found = friend
                                break
                            }
                        }
                    }
                    if (found != null) {
                        onFriendTapped(found)
                    }
                }
            }
    ) {
        val width = size.width
        val height = size.height
        val center = Offset(width / 2f, height / 2f)

        // Draw Base Background
        drawRect(color = bgColor)

        // Helper to project Lat/Lng to Canvas Pixels relative to camera
        fun project(lat: Double, lng: Double): Offset {
            val scale = 2.0.pow(zoomLevel.toDouble()).toFloat() * 18f
            val x = center.x + ((lng - cameraLng) * scale * cos(Math.toRadians(cameraLat))).toFloat()
            val y = center.y - ((lat - cameraLat) * scale).toFloat()
            return Offset(x, y)
        }

        // 1. Draw Water Bodies (San Francisco Bay / Coastline shape)
        val waterPath = Path().apply {
            val p1 = project(37.8200, -122.3700)
            val p2 = project(37.8100, -122.3900)
            val p3 = project(37.7950, -122.3920)
            val p4 = project(37.7700, -122.3800)
            val p5 = project(37.7400, -122.3700)
            val pOffscreen = Offset(width + 400f, height + 400f)
            val pTopRight = Offset(width + 400f, -400f)

            moveTo(p1.x, p1.y)
            cubicTo(p2.x, p2.y, p3.x, p3.y, p4.x, p4.y)
            lineTo(p5.x, p5.y)
            lineTo(pOffscreen.x, pOffscreen.y)
            lineTo(pTopRight.x, pTopRight.y)
            close()
        }
        drawPath(waterPath, color = waterColor)

        // 2. Draw Parks (Golden Gate Park, Presidio, Dolores Park)
        val ggParkP1 = project(37.7730, -122.4850)
        val ggParkP2 = project(37.7660, -122.4500)
        drawRoundRect(
            color = parkColor,
            topLeft = Offset(min(ggParkP1.x, ggParkP2.x), min(ggParkP1.y, ggParkP2.y)),
            size = Size(abs(ggParkP2.x - ggParkP1.x), abs(ggParkP2.y - ggParkP1.y)),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f)
        )

        val doloresP1 = project(37.7610, -122.4280)
        val doloresP2 = project(37.7580, -122.4250)
        drawRoundRect(
            color = parkColor,
            topLeft = Offset(min(doloresP1.x, doloresP2.x), min(doloresP1.y, doloresP2.y)),
            size = Size(abs(doloresP2.x - doloresP1.x), abs(doloresP2.y - doloresP1.y)),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
        )

        // 3. Draw Road Grid Hierarchy
        // Major Arteries: Market Street (diagonal), Van Ness (vertical), Mission, Geary (horizontal)
        val marketStart = project(37.7950, -122.3950)
        val marketEnd = project(37.7550, -122.4400)
        drawLine(highwayCasing, marketStart, marketEnd, strokeWidth = 14f, cap = StrokeCap.Round)
        drawLine(highwayColor, marketStart, marketEnd, strokeWidth = 10f, cap = StrokeCap.Round)

        val vanNessStart = project(37.8050, -122.4240)
        val vanNessEnd = project(37.7500, -122.4180)
        drawLine(highwayCasing, vanNessStart, vanNessEnd, strokeWidth = 12f, cap = StrokeCap.Round)
        drawLine(highwayColor, vanNessStart, vanNessEnd, strokeWidth = 8f, cap = StrokeCap.Round)

        val gearyStart = project(37.7850, -122.4050)
        val gearyEnd = project(37.7800, -122.4800)
        drawLine(highwayCasing, gearyStart, gearyEnd, strokeWidth = 10f, cap = StrokeCap.Round)
        drawLine(highwayColor, gearyStart, gearyEnd, strokeWidth = 6f, cap = StrokeCap.Round)

        // Secondary Residential Streets Grid
        for (i in -8..8) {
            val latOffset = i * 0.007
            val pA = project(37.7700 + latOffset, -122.4600)
            val pB = project(37.7700 + latOffset, -122.3900)
            drawLine(roadColor, pA, pB, strokeWidth = 3.5f, cap = StrokeCap.Round)
        }
        for (j in -8..8) {
            val lngOffset = j * 0.007
            val pA = project(37.7400, -122.4200 + lngOffset)
            val pB = project(37.8000, -122.4200 + lngOffset)
            drawLine(roadColor, pA, pB, strokeWidth = 3.5f, cap = StrokeCap.Round)
        }

        // 4. Draw Active Shared Routes (Glowing accent line)
        for (route in activeRoutes) {
            val start = project(route.startLatitude, route.startLongitude)
            val end = project(route.endLatitude, route.endLongitude)

            // Outer glow
            drawLine(
                color = AtlasForestGreenLight.copy(alpha = 0.35f),
                start = start,
                end = end,
                strokeWidth = 16f,
                cap = StrokeCap.Round
            )
            // Core route line
            drawLine(
                color = AtlasForestGreenLight,
                start = start,
                end = end,
                strokeWidth = 6f,
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 14f), 0f)
            )
        }

        // 5. Draw Friends on Map
        for (friend in friends) {
            val pos = project(friend.latitude, friend.longitude)
            friendScreenPositions[friend.id] = pos

            val isSelected = selectedFriend?.id == friend.id
            val avatar = AvatarCatalog.getAvatar(friend.friendAvatarId)
            val vehicle = AvatarCatalog.getAvatar(friend.friendVehicleId)

            if (friend.isLiveSharing) {
                // Pulse aura
                drawCircle(
                    color = avatar.accentColor.copy(alpha = pulseAlpha * 0.5f),
                    radius = 34f * pulseScale,
                    center = pos
                )
            }

            // Selection halo
            if (isSelected) {
                drawCircle(
                    color = Color.White,
                    radius = 38f,
                    center = pos,
                    style = Stroke(width = 4f)
                )
            }

            // Outer shadow / border
            drawCircle(
                color = Color.Black.copy(alpha = 0.25f),
                radius = 29f,
                center = Offset(pos.x, pos.y + 3f)
            )

            // Main avatar pin surface
            drawCircle(
                color = if (isSelected) avatar.accentColor else Color.White,
                radius = 26f,
                center = pos
            )
            drawCircle(
                color = avatar.accentColor,
                radius = 23f,
                center = pos
            )

            // Vehicle companion indicator
            val vehPos = Offset(pos.x + 22f, pos.y - 18f)
            drawCircle(
                color = vehicle.accentColor,
                radius = 12f,
                center = vehPos
            )
            drawCircle(
                color = Color.White,
                radius = 12f,
                center = vehPos,
                style = Stroke(width = 2f)
            )
        }

        // 6. Draw Current User
        if (currentUser != null && isSharingLocation) {
            val userPos = project(currentUser.latitude, currentUser.longitude)

            // Radiating user beacon
            drawCircle(
                color = AtlasForestGreenLight.copy(alpha = pulseAlpha),
                radius = 44f * pulseScale,
                center = userPos
            )
            drawCircle(
                color = AtlasForestGreenLight.copy(alpha = 0.2f),
                radius = 28f,
                center = userPos
            )
            drawCircle(
                color = Color.White,
                radius = 18f,
                center = userPos
            )
            drawCircle(
                color = AtlasForestGreenLight,
                radius = 13f,
                center = userPos
            )
        }
    }
}
