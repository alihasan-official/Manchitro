package com.example.ui.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.example.AtlasApplication
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.AuthViewModel
import com.example.ui.chat.ChatScreen
import com.example.ui.friends.FriendsScreen
import com.example.ui.map.MapScreen
import com.example.ui.map.MapViewModel
import com.example.ui.profile.ProfileScreen
import com.example.ui.stories.StoriesScreen

enum class AtlasDestination(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    MAP("Map", Icons.Default.Explore, Icons.Outlined.Explore, "nav_map"),
    STORIES("Stories", Icons.Default.AutoStories, Icons.Outlined.AutoStories, "nav_stories"),
    CHATS("Chats", Icons.Default.ChatBubble, Icons.Outlined.ChatBubbleOutline, "nav_chats"),
    FRIENDS("Circle", Icons.Default.People, Icons.Outlined.PeopleOutline, "nav_friends"),
    PROFILE("Profile", Icons.Default.Person, Icons.Outlined.PersonOutline, "nav_profile")
}

@Composable
fun AtlasApp(
    authViewModel: AuthViewModel,
    mapViewModel: MapViewModel
) {
    val authUiState by authViewModel.uiState.collectAsState()
    var currentDestination by remember { mutableStateOf(AtlasDestination.MAP) }
    var selectedChatContact by remember { mutableStateOf<String?>(null) }

    val app = AtlasApplication.instance

    if (!authUiState.isLoggedIn) {
        AuthScreen(authViewModel = authViewModel)
    } else {
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.testTag("atlas_bottom_nav")
                ) {
                    AtlasDestination.entries.forEach { dest ->
                        val isSelected = currentDestination == dest
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = dest },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                    contentDescription = dest.title
                                )
                            },
                            label = { Text(dest.title) },
                            modifier = Modifier.testTag(dest.testTag)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentDestination) {
                    AtlasDestination.MAP -> {
                        MapScreen(
                            mapViewModel = mapViewModel,
                            onNavigateToChat = { friendId, _ ->
                                selectedChatContact = "conv_${friendId.takeLast(4)}"
                                currentDestination = AtlasDestination.CHATS
                            }
                        )
                    }
                    AtlasDestination.STORIES -> {
                        StoriesScreen(
                            currentUser = authUiState.currentUser,
                            socialRepository = app.socialRepository,
                            onNavigateToChat = { friendId, _ ->
                                selectedChatContact = "conv_${friendId.takeLast(4)}"
                                currentDestination = AtlasDestination.CHATS
                            }
                        )
                    }
                    AtlasDestination.CHATS -> {
                        ChatScreen(
                            currentUser = authUiState.currentUser,
                            socialRepository = app.socialRepository,
                            geminiRepository = app.geminiRepository,
                            initialConversationId = selectedChatContact,
                            onNavigateToMapLocation = { lat, lng ->
                                mapViewModel.updateCamera(lat, lng, 16f)
                                currentDestination = AtlasDestination.MAP
                            }
                        )
                    }
                    AtlasDestination.FRIENDS -> {
                        FriendsScreen(
                            currentUser = authUiState.currentUser,
                            socialRepository = app.socialRepository,
                            onNavigateToChat = { friendId, _ ->
                                selectedChatContact = "conv_${friendId.takeLast(4)}"
                                currentDestination = AtlasDestination.CHATS
                            },
                            onNavigateToMap = { lat, lng ->
                                mapViewModel.updateCamera(lat, lng, 16f)
                                currentDestination = AtlasDestination.MAP
                            }
                        )
                    }
                    AtlasDestination.PROFILE -> {
                        ProfileScreen(
                            currentUser = authUiState.currentUser,
                            authViewModel = authViewModel,
                            authRepository = app.authRepository,
                            geminiRepository = app.geminiRepository
                        )
                    }
                }
            }
        }
    }
}
