package com.example.ui.friends

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FriendshipEntity
import com.example.data.repository.SocialRepository
import com.example.model.AvatarCatalog
import com.example.model.User
import com.example.ui.theme.AtlasSuccess
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    currentUser: User?,
    socialRepository: SocialRepository,
    onNavigateToChat: (String, String) -> Unit,
    onNavigateToMap: (Double, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var friends by remember { mutableStateOf<List<FriendshipEntity>>(emptyList()) }
    var pendingRequests by remember { mutableStateOf<List<FriendshipEntity>>(emptyList()) }
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(currentUser) {
        if (currentUser != null) {
            launch {
                socialRepository.getFriendsFlow(currentUser.id).collectLatest {
                    friends = it
                }
            }
            launch {
                socialRepository.getPendingRequestsFlow(currentUser.id).collectLatest {
                    pendingRequests = it
                }
            }
        }
    }

    val filteredFriends = remember(friends, searchQuery) {
        if (searchQuery.isBlank()) friends
        else friends.filter {
            it.friendDisplayName.contains(searchQuery, ignoreCase = true) ||
            it.friendUsername.contains(searchQuery, ignoreCase = true) ||
            it.friendPhoneNumber.contains(searchQuery)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Circle",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                actions = {
                    IconButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier.testTag("button_add_friend")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = "Add Friend",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier.testTag("friends_screen")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search friends by name or handle...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            // User's Handle & WhatsApp Phone Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.ContactPhone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Your Identity (Connect via Handle or Phone)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "@${currentUser?.username ?: "me"}" +
                                            if (!currentUser?.phoneNumber.isNullOrBlank()) " • ${currentUser?.phoneNumber}" else "",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        FilledTonalButton(
                            onClick = {
                                val sendIntent = android.content.Intent().apply {
                                    action = android.content.Intent.ACTION_SEND
                                    putExtra(
                                        android.content.Intent.EXTRA_TEXT,
                                        "Hey! Connect with me on Atlas Social Map. Find me by my phone number ${currentUser?.phoneNumber.orEmpty()} or handle @${currentUser?.username ?: "me"}"
                                    )
                                    type = "text/plain"
                                }
                                val shareIntent = android.content.Intent.createChooser(sendIntent, "Share Atlas Invite via WhatsApp or SMS")
                                context.startActivity(shareIntent)
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Outlined.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Share Invite via WhatsApp / SMS", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                        }
                    }
                }
            }

            // Pending Requests Section
            if (pendingRequests.isNotEmpty()) {
                item {
                    Text(
                        text = "Pending Requests (${pendingRequests.size})",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                    )
                }

                items(pendingRequests) { req ->
                    val avatar = AvatarCatalog.getAvatar(req.friendAvatarId)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(avatar.accentColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = avatar.iconEmoji, fontSize = 22.sp)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = req.friendDisplayName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "@${req.friendUsername}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(
                                    onClick = {
                                        scope.launch { socialRepository.acceptFriendRequest(req.id) }
                                    },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Accept")
                                }
                                OutlinedButton(
                                    onClick = {
                                        scope.launch { socialRepository.rejectFriendRequest(req.id) }
                                    },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Decline")
                                }
                            }
                        }
                    }
                }
            }

            // Accepted Friends Header
            item {
                Text(
                    text = "Trusted Friends (${filteredFriends.size})",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                )
            }

            if (filteredFriends.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isNotBlank()) "No friends match '$searchQuery'" else "No friends added yet. Tap + to invite your friends!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(filteredFriends) { friend ->
                    val avatar = AvatarCatalog.getAvatar(friend.friendAvatarId)
                    val vehicle = AvatarCatalog.getAvatar(friend.friendVehicleId)

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(avatar.accentColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = avatar.iconEmoji, fontSize = 22.sp)
                                }
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .align(Alignment.BottomEnd)
                                        .clip(CircleShape)
                                        .background(vehicle.accentColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = vehicle.iconEmoji, fontSize = 9.sp)
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = friend.friendDisplayName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "@${friend.friendUsername}" +
                                            (if (friend.friendPhoneNumber.isNotBlank()) " • 📱 ${friend.friendPhoneNumber}" else "") +
                                            " • ${friend.statusMessage}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { onNavigateToMap(friend.latitude, friend.longitude) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Place,
                                        contentDescription = "View on Map",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }

                                IconButton(
                                    onClick = { onNavigateToChat(friend.friendId, friend.friendDisplayName) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ChatBubbleOutline,
                                        contentDescription = "Chat",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AddFriendDialog(
                onDismiss = { showAddDialog = false },
                onAdd = { identifierToAdd ->
                    currentUser?.let { user ->
                        scope.launch {
                            socialRepository.sendFriendRequest(user.id, identifierToAdd)
                            showAddDialog = false
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun AddFriendDialog(
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit
) {
    var targetIdentifier by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PersonAdd,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Add via Phone or Handle")
            }
        },
        text = {
            Column {
                Text(
                    "Connect just like WhatsApp! Enter your friend's phone number or unique @username to instantly connect and view their live map updates.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = targetIdentifier,
                    onValueChange = { targetIdentifier = it },
                    label = { Text("Phone Number or @Username") },
                    placeholder = { Text("e.g. +1 (415) 555-0192 or maya_sun") },
                    leadingIcon = {
                        Icon(
                            imageVector = if (targetIdentifier.any { it.isDigit() }) Icons.Outlined.Phone else Icons.Outlined.AlternateEmail,
                            contentDescription = null
                        )
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (targetIdentifier.isNotBlank()) onAdd(targetIdentifier) },
                enabled = targetIdentifier.isNotBlank()
            ) {
                Text("Connect")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
