package com.example.ui.map

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AvatarCatalog
import com.example.ui.ai.AiAssistantSheet
import com.example.ui.theme.AtlasSuccess

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    mapViewModel: MapViewModel,
    onNavigateToChat: (String, String) -> Unit, // friendId, friendName
    modifier: Modifier = Modifier
) {
    val uiState by mapViewModel.uiState.collectAsState()
    var showAiSheet by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("map_screen")
    ) {
        // 1. Canvas Interactive Map
        AtlasMapView(
            cameraLat = uiState.cameraLat,
            cameraLng = uiState.cameraLng,
            zoomLevel = uiState.zoomLevel,
            mapStyle = uiState.mapStyle,
            currentUser = uiState.currentUser,
            isSharingLocation = uiState.isSharingLocation,
            friends = uiState.friends,
            activeRoutes = uiState.activeRoutes,
            selectedFriend = uiState.selectedFriend,
            onFriendTapped = { friend ->
                mapViewModel.selectFriend(friend)
            },
            onMapPan = { dLat, dLng ->
                mapViewModel.updateCamera(
                    uiState.cameraLat + dLat,
                    uiState.cameraLng + dLng,
                    uiState.zoomLevel
                )
            },
            onMapZoom = { factor ->
                val newZoom = (uiState.zoomLevel * factor).coerceIn(10f, 18f)
                mapViewModel.updateCamera(uiState.cameraLat, uiState.cameraLng, newZoom)
            },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top Header Overlay (Status, Privacy toggle, Map style)
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Privacy / Live Sharing Pill Toggle
                Surface(
                    onClick = { mapViewModel.toggleLocationSharing() },
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                    shadowElevation = 4.dp,
                    modifier = Modifier.testTag("toggle_sharing_pill")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (uiState.isSharingLocation) AtlasSuccess else Color.Gray)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (uiState.isSharingLocation) "Sharing Live" else "Ghost Mode (Paused)",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Map Style Switcher
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                    shadowElevation = 4.dp
                ) {
                    Row(modifier = Modifier.padding(4.dp)) {
                        IconButton(
                            onClick = {
                                val nextStyle = if (uiState.mapStyle == "SOFT_LIGHT") "MIDNIGHT" else "SOFT_LIGHT"
                                mapViewModel.setMapStyle(nextStyle)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (uiState.mapStyle == "MIDNIGHT") Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Map Theme",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Grounded Search Bar Trigger
            Surface(
                onClick = { showAiSheet = true },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("map_search_bar")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Search places with Google Maps & Gemini...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 3. Floating Quick Action Controls (Locate me, Fit all, Gemini AI)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FloatingActionButton(
                onClick = { showAiSheet = true },
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                shape = CircleShape,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("fab_gemini_ai")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Gemini AI rendezvous",
                    modifier = Modifier.size(22.dp)
                )
            }

            FloatingActionButton(
                onClick = { mapViewModel.fitAllFriends() },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                shape = CircleShape,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("fab_fit_all")
            ) {
                Icon(
                    imageVector = Icons.Outlined.People,
                    contentDescription = "Fit all friends",
                    modifier = Modifier.size(22.dp)
                )
            }

            FloatingActionButton(
                onClick = { mapViewModel.centerOnUser() },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                shape = CircleShape,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("fab_locate_me")
            ) {
                Icon(
                    imageVector = Icons.Default.MyLocation,
                    contentDescription = "Locate Me",
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // 4. Bottom Friends Rail
        Card(
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "Circle on Map (${uiState.friends.size})",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(uiState.friends) { friend ->
                        val avatar = AvatarCatalog.getAvatar(friend.friendAvatarId)
                        val vehicle = AvatarCatalog.getAvatar(friend.friendVehicleId)

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { mapViewModel.selectFriend(friend) }
                                .padding(4.dp)
                        ) {
                            Box {
                                Box(
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(CircleShape)
                                        .background(avatar.accentColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = avatar.iconEmoji, fontSize = 24.sp)
                                }

                                // Vehicle chip
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .align(Alignment.BottomEnd)
                                        .clip(CircleShape)
                                        .background(vehicle.accentColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = vehicle.iconEmoji, fontSize = 10.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = friend.friendDisplayName.split(" ").first(),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Friend Detail Sheet
        uiState.selectedFriend?.let { friend ->
            FriendDetailSheet(
                friend = friend,
                onDismiss = { mapViewModel.selectFriend(null) },
                onMessageClick = { friendId, friendName ->
                    onNavigateToChat(friendId, friendName)
                },
                onCenterMap = {
                    mapViewModel.updateCamera(friend.latitude, friend.longitude, 16f)
                },
                onPlanRendezvous = {
                    showAiSheet = true
                }
            )
        }

        // Gemini AI Assistant Bottom Sheet
        if (showAiSheet) {
            AiAssistantSheet(
                mapViewModel = mapViewModel,
                onDismiss = { showAiSheet = false }
            )
        }
    }
}
