package com.example.ui.map

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FriendshipEntity
import com.example.data.local.RouteEntity
import com.example.data.local.SessionManager
import com.example.data.repository.AuthRepository
import com.example.data.repository.GeminiRepository
import com.example.data.repository.GeminiResult
import com.example.data.repository.SocialRepository
import com.example.model.User
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class MapUiState(
    val currentUser: User? = null,
    val friends: List<FriendshipEntity> = emptyList(),
    val activeRoutes: List<RouteEntity> = emptyList(),
    val selectedFriend: FriendshipEntity? = null,
    val mapStyle: String = "SOFT_LIGHT", // "SOFT_LIGHT", "MIDNIGHT", "CLASSIC"
    val isSharingLocation: Boolean = true,
    val cameraLat: Double = 37.7749,
    val cameraLng: Double = -122.4194,
    val zoomLevel: Float = 14f,
    val searchQuery: String = "",
    val searchResults: String? = null,
    val isSearching: Boolean = false,
    val rendezvousPlan: String? = null,
    val isCalculatingRendezvous: Boolean = false
)

class MapViewModel(
    private val authRepository: AuthRepository,
    private val socialRepository: SocialRepository,
    private val sessionManager: SessionManager,
    private val geminiRepository: GeminiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MapUiState())
    val uiState: StateFlow<MapUiState> = _uiState.asStateFlow()

    init {
        loadData()
        startLiveMovementSimulation()
    }

    private fun loadData() {
        viewModelScope.launch {
            authRepository.currentUserIdFlow.collectLatest { userId ->
                if (userId != null) {
                    val user = authRepository.getLoggedInUser()
                    _uiState.update { it.copy(currentUser = user, isSharingLocation = user?.isSharingLocation ?: true) }

                    // Listen to friends
                    launch {
                        socialRepository.getFriendsFlow(userId).collect { friendList ->
                            _uiState.update { it.copy(friends = friendList) }
                        }
                    }

                    // Listen to routes
                    launch {
                        socialRepository.getActiveRoutesFlow().collect { routes ->
                            _uiState.update { it.copy(activeRoutes = routes) }
                        }
                    }
                }
            }
        }

        viewModelScope.launch {
            sessionManager.mapStyleFlow.collect { style ->
                _uiState.update { it.copy(mapStyle = style) }
            }
        }
    }

    // Periodic slight interpolation simulation for friend movement to demonstrate real-time social dynamics
    private fun startLiveMovementSimulation() {
        viewModelScope.launch {
            while (true) {
                delay(6000)
                val currentFriends = _uiState.value.friends
                if (currentFriends.isNotEmpty()) {
                    val updated = currentFriends.map { f ->
                        if (f.isLiveSharing) {
                            val dLat = (Math.random() - 0.5) * 0.0004
                            val dLng = (Math.random() - 0.5) * 0.0004
                            f.copy(
                                latitude = f.latitude + dLat,
                                longitude = f.longitude + dLng,
                                lastUpdated = System.currentTimeMillis()
                            )
                        } else f
                    }
                    _uiState.update { it.copy(friends = updated) }
                }
            }
        }
    }

    fun selectFriend(friend: FriendshipEntity?) {
        _uiState.update {
            it.copy(
                selectedFriend = friend,
                cameraLat = friend?.latitude ?: it.cameraLat,
                cameraLng = friend?.longitude ?: it.cameraLng
            )
        }
    }

    fun centerOnUser() {
        val user = _uiState.value.currentUser ?: return
        _uiState.update {
            it.copy(cameraLat = user.latitude, cameraLng = user.longitude, zoomLevel = 15f)
        }
    }

    fun fitAllFriends() {
        val friends = _uiState.value.friends
        val user = _uiState.value.currentUser
        if (friends.isEmpty() && user == null) return

        val allLats = friends.map { it.latitude } + listOfNotNull(user?.latitude)
        val allLngs = friends.map { it.longitude } + listOfNotNull(user?.longitude)

        val avgLat = allLats.average()
        val avgLng = allLngs.average()
        _uiState.update {
            it.copy(cameraLat = avgLat, cameraLng = avgLng, zoomLevel = 13.2f)
        }
    }

    fun toggleLocationSharing() {
        val current = _uiState.value.isSharingLocation
        val next = !current
        _uiState.update { it.copy(isSharingLocation = next) }
        viewModelScope.launch {
            authRepository.updateLocationSharing(next)
        }
    }

    fun setMapStyle(style: String) {
        _uiState.update { it.copy(mapStyle = style) }
        viewModelScope.launch {
            sessionManager.setMapStyle(style)
        }
    }

    fun updateCamera(lat: Double, lng: Double, zoom: Float) {
        _uiState.update { it.copy(cameraLat = lat, cameraLng = lng, zoomLevel = zoom) }
    }

    // Maps Grounding search using gemini-3.8-flash with googleMaps tool
    fun searchPlaces(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true, searchQuery = query) }
            val user = _uiState.value.currentUser
            val locStr = "${user?.latitude ?: 37.7749}, ${user?.longitude ?: -122.4194}"
            when (val result = geminiRepository.queryMapPlaces(query, locStr)) {
                is GeminiResult.Success -> {
                    _uiState.update { it.copy(isSearching = false, searchResults = result.data) }
                }
                is GeminiResult.Error -> {
                    _uiState.update { it.copy(isSearching = false, searchResults = "Search error: ${result.message}") }
                }
            }
        }
    }

    // High Thinking calculation using gemini-4-argon with thinkingLevel = HIGH
    fun calculateOptimalRendezvous(promptDetails: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isCalculatingRendezvous = true) }
            val friendsStr = _uiState.value.friends.joinToString("; ") {
                "${it.friendDisplayName} at (${it.latitude}, ${it.longitude})"
            }
            when (val result = geminiRepository.calculateRendezvousPlan(friendsStr, promptDetails)) {
                is GeminiResult.Success -> {
                    _uiState.update { it.copy(isCalculatingRendezvous = false, rendezvousPlan = result.data) }
                }
                is GeminiResult.Error -> {
                    _uiState.update { it.copy(isCalculatingRendezvous = false, rendezvousPlan = "Could not compute: ${result.message}") }
                }
            }
        }
    }

    fun clearSearch() {
        _uiState.update { it.copy(searchQuery = "", searchResults = null, rendezvousPlan = null) }
    }
}
