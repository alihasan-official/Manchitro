package com.example.ui.profile

import android.graphics.Bitmap
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AuthRepository
import com.example.data.repository.GeminiRepository
import com.example.data.repository.GeminiResult
import com.example.model.AvatarCatalog
import com.example.model.User
import com.example.ui.auth.AuthViewModel
import com.example.ui.theme.AtlasSuccess
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    currentUser: User?,
    authViewModel: AuthViewModel,
    authRepository: AuthRepository,
    geminiRepository: GeminiRepository,
    modifier: Modifier = Modifier
) {
    var selectedAvatarId by remember { mutableStateOf(currentUser?.avatarId ?: "char_explorer") }
    var selectedVehicleId by remember { mutableStateOf(currentUser?.vehicleId ?: "veh_ev") }
    var isSharing by remember { mutableStateOf(currentUser?.isSharingLocation ?: true) }

    // AI Avatar Generator state (gemini-3-pro-image-preview with 1K, 2K, 4K)
    var showAiAvatarDialog by remember { mutableStateOf(false) }
    var aiPrompt by remember { mutableStateOf("") }
    var selectedResolution by remember { mutableStateOf("1K") } // "1K", "2K", "4K"
    var isGeneratingAiAvatar by remember { mutableStateOf(false) }
    var aiGeneratedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var aiAvatarError by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()
    val currentAvatar = AvatarCatalog.getAvatar(selectedAvatarId)
    val currentVehicle = AvatarCatalog.getAvatar(selectedVehicleId)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Profile & Identity",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        modifier = modifier.testTag("profile_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile Header with selected Avatar
            Box(contentAlignment = Alignment.Center) {
                if (aiGeneratedBitmap != null) {
                    Image(
                        bitmap = aiGeneratedBitmap!!.asImageBitmap(),
                        contentDescription = "AI Avatar",
                        modifier = Modifier
                            .size(96.dp)
                            .clip(CircleShape)
                            .border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(96.dp)
                            .clip(CircleShape)
                            .background(currentAvatar.accentColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = currentAvatar.iconEmoji, fontSize = 44.sp)
                    }
                }

                // Companion vehicle badge
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .align(Alignment.BottomEnd)
                        .clip(CircleShape)
                        .background(currentVehicle.accentColor)
                        .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = currentVehicle.iconEmoji, fontSize = 16.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = currentUser?.displayName ?: "Explorer",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "@${currentUser?.username ?: "me"} • ${currentUser?.email ?: ""}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (currentUser?.isGuest == true) {
                Spacer(modifier = Modifier.height(6.dp))
                AssistChip(
                    onClick = {},
                    label = { Text("Guest Preview Account") },
                    leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp)) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // AI Avatar Creator trigger
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showAiAvatarDialog = true }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Generate AI Avatar with Gemini",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Model: gemini-3-pro-image-preview • 1K, 2K, 4K resolution",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Avatar Selector Rail
            Text(
                text = "Character Persona",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(AvatarCatalog.characterAvatars) { av ->
                    val isSelected = selectedAvatarId == av.id
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                selectedAvatarId = av.id
                                scope.launch {
                                    authRepository.updateAvatars(av.id, selectedVehicleId)
                                }
                            }
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .border(
                                    width = if (isSelected) 3.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent,
                                    shape = CircleShape
                                )
                                .padding(4.dp)
                                .clip(CircleShape)
                                .background(av.accentColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = av.iconEmoji, fontSize = 26.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = av.name.split(" ").first(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Vehicle Selector Rail
            Text(
                text = "Vehicle & Companion Marker",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(AvatarCatalog.vehicleAvatars) { veh ->
                    val isSelected = selectedVehicleId == veh.id
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                selectedVehicleId = veh.id
                                scope.launch {
                                    authRepository.updateAvatars(selectedAvatarId, veh.id)
                                }
                            }
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .border(
                                    width = if (isSelected) 3.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent,
                                    shape = CircleShape
                                )
                                .padding(4.dp)
                                .clip(CircleShape)
                                .background(veh.accentColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = veh.iconEmoji, fontSize = 26.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = veh.name.split(" ").first(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Phone Number & WhatsApp Discovery Card
            var editingPhone by remember { mutableStateOf(false) }
            var phoneInput by remember(currentUser) { mutableStateOf(currentUser?.phoneNumber.orEmpty()) }

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.Phone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "WhatsApp / Phone Discovery",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        TextButton(onClick = { editingPhone = !editingPhone }) {
                            Text(if (editingPhone) "Cancel" else if (phoneInput.isBlank()) "Add" else "Edit")
                        }
                    }

                    if (editingPhone) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { phoneInput = it },
                            placeholder = { Text("e.g. +1 (415) 555-0199") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                authViewModel.updatePhoneNumber(phoneInput)
                                editingPhone = false
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Phone Number")
                        }
                    } else {
                        Text(
                            text = if (currentUser?.phoneNumber.isNullOrBlank()) "No phone number linked. Add one so friends can connect directly using your mobile number."
                            else "Linked Number: ${currentUser?.phoneNumber}. Friends can find you via WhatsApp-style phone lookup or @${currentUser?.username}.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Privacy & Sharing Settings
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Location Privacy & Sharing",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Live Circle Sharing",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                            )
                            Text(
                                text = if (isSharing) "Approved friends can view your live map location" else "Ghost Mode: Location is completely hidden",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isSharing,
                            onCheckedChange = {
                                isSharing = it
                                scope.launch { authRepository.updateLocationSharing(it) }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Account Actions
            OutlinedButton(
                onClick = { authViewModel.signOut() },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("button_sign_out")
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out", fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            TextButton(
                onClick = { authViewModel.deleteAccount() },
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.testTag("button_delete_account")
            ) {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Delete Account & Erase All Records", style = MaterialTheme.typography.bodySmall)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Atlas v1.0 • Map data © OpenStreetMap contributors",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        // AI Avatar Generator Modal
        if (showAiAvatarDialog) {
            AlertDialog(
                onDismissRequest = { showAiAvatarDialog = false },
                title = { Text("Gemini 3 Pro Image Generator") },
                text = {
                    Column {
                        Text(
                            text = "Model: gemini-3-pro-image-preview. Select desired resolution and prompt:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Resolution Affordance: 1K, 2K, 4K
                        Text(
                            text = "Image Resolution:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            listOf("1K", "2K", "4K").forEach { res ->
                                FilterChip(
                                    selected = selectedResolution == res,
                                    onClick = { selectedResolution = res },
                                    label = { Text(res, fontWeight = FontWeight.Bold) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = aiPrompt,
                            onValueChange = { aiPrompt = it },
                            placeholder = { Text("e.g. Sleek emerald space helmet avatar") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (aiAvatarError != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = aiAvatarError ?: "",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        if (isGeneratingAiAvatar) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Generating $selectedResolution artwork...", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            isGeneratingAiAvatar = true
                            aiAvatarError = null
                            scope.launch {
                                when (val res = geminiRepository.generateCustomAvatarImage(aiPrompt, selectedResolution)) {
                                    is GeminiResult.Success -> {
                                        aiGeneratedBitmap = res.data
                                        isGeneratingAiAvatar = false
                                        showAiAvatarDialog = false
                                    }
                                    is GeminiResult.Error -> {
                                        aiAvatarError = res.message
                                        isGeneratingAiAvatar = false
                                    }
                                }
                            }
                        },
                        enabled = !isGeneratingAiAvatar && aiPrompt.isNotBlank()
                    ) {
                        Text("Generate")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAiAvatarDialog = false }) { Text("Cancel") }
                }
            )
        }
    }
}
