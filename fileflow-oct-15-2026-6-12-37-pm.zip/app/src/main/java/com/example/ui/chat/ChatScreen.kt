package com.example.ui.chat

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import com.example.data.repository.GeminiRepository
import com.example.data.repository.GeminiResult
import com.example.data.repository.SocialRepository
import com.example.model.AvatarCatalog
import com.example.model.User
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    currentUser: User?,
    socialRepository: SocialRepository,
    geminiRepository: GeminiRepository,
    initialConversationId: String? = null,
    onNavigateToMapLocation: (Double, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var conversations by remember { mutableStateOf<List<ConversationEntity>>(emptyList()) }
    var activeConvId by remember { mutableStateOf(initialConversationId) }
    var activeConvTitle by remember { mutableStateOf("") }
    var showNewGroupDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        socialRepository.getConversationsFlow().collectLatest {
            conversations = it
            if (activeConvId != null) {
                val current = it.firstOrNull { c -> c.id == activeConvId }
                if (current != null) activeConvTitle = current.title
            }
        }
    }

    if (activeConvId != null) {
        // Conversation Detail Screen
        ConversationDetailView(
            conversationId = activeConvId!!,
            conversationTitle = activeConvTitle.ifBlank { "Chat" },
            currentUser = currentUser,
            socialRepository = socialRepository,
            geminiRepository = geminiRepository,
            onBack = { activeConvId = null },
            onViewLocation = onNavigateToMapLocation
        )
    } else {
        // Conversation List Screen
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            "Chats",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    actions = {
                        IconButton(
                            onClick = { showNewGroupDialog = true },
                            modifier = Modifier.testTag("button_create_group")
                        ) {
                            Icon(
                                imageVector = Icons.Default.GroupAdd,
                                contentDescription = "Create Group",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            modifier = modifier.testTag("chat_list_screen")
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (conversations.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No active conversations yet. Start one from your friends list!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(conversations) { conv ->
                        val avatar = AvatarCatalog.getAvatar(conv.avatarId)
                        val formattedTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(conv.lastMessageTimestamp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    activeConvId = conv.id
                                    activeConvTitle = conv.title
                                }
                                .padding(horizontal = 20.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(avatar.accentColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = avatar.iconEmoji, fontSize = 24.sp)
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = conv.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = formattedTime,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = conv.lastMessageText,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        modifier = Modifier.weight(1f)
                                    )

                                    if (conv.unreadCount > 0) {
                                        Box(
                                            modifier = Modifier
                                                .padding(start = 8.dp)
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primary),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "${conv.unreadCount}",
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 20.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        )
                    }
                }
            }
        }
    }

    if (showNewGroupDialog) {
        CreateGroupDialog(
            onDismiss = { showNewGroupDialog = false },
            onCreate = { title ->
                scope.launch {
                    val newId = socialRepository.createGroup(
                        title = title,
                        creatorId = currentUser?.id ?: "me",
                        creatorName = currentUser?.displayName ?: "Me",
                        initialMembers = listOf("friend_maya", "friend_liam")
                    )
                    showNewGroupDialog = false
                    activeConvId = newId
                    activeConvTitle = title
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationDetailView(
    conversationId: String,
    conversationTitle: String,
    currentUser: User?,
    socialRepository: SocialRepository,
    geminiRepository: GeminiRepository,
    onBack: () -> Unit,
    onViewLocation: (Double, Double) -> Unit
) {
    BackHandler { onBack() }

    var messages by remember { mutableStateOf<List<MessageEntity>>(emptyList()) }
    var inputText by remember { mutableStateOf("") }
    var smartReplies by remember { mutableStateOf<List<String>>(emptyList()) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(conversationId) {
        socialRepository.getMessagesFlow(conversationId).collectLatest { msgs ->
            messages = msgs
            if (msgs.isNotEmpty()) {
                listState.animateScrollToItem(msgs.size - 1)
                // Load smart replies based on last incoming message
                val lastIncoming = msgs.lastOrNull { !it.isMine }
                if (lastIncoming != null) {
                    when (val res = geminiRepository.quickSmartReply(lastIncoming.content)) {
                        is GeminiResult.Success -> smartReplies = res.data
                        else -> smartReplies = emptyList()
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                title = {
                    Column {
                        Text(
                            text = conversationTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Private encrypted channel",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(messages) { msg ->
                    val isMine = msg.isMine || msg.senderId == currentUser?.id
                    val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(msg.timestamp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
                    ) {
                        if (!isMine && msg.senderName.isNotBlank()) {
                            Text(
                                text = msg.senderName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(start = 8.dp, bottom = 2.dp)
                            )
                        }

                        if (msg.messageType == "LOCATION" && msg.latitude != null && msg.longitude != null) {
                            // Interactive Location Card Bubble
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                modifier = Modifier
                                    .widthIn(max = 280.dp)
                                    .clickable { onViewLocation(msg.latitude, msg.longitude) }
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Place,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Shared Location",
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg.placeName ?: "San Francisco Coordinates",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Tap to view on map →",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        } else {
                            // Text Bubble
                            Surface(
                                shape = RoundedCornerShape(
                                    topStart = 18.dp,
                                    topEnd = 18.dp,
                                    bottomStart = if (isMine) 18.dp else 4.dp,
                                    bottomEnd = if (isMine) 4.dp else 18.dp
                                ),
                                color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.widthIn(max = 280.dp)
                            ) {
                                Text(
                                    text = msg.content,
                                    color = if (isMine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                )
                            }
                        }

                        Text(
                            text = timeStr,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Gemini Quick Smart Replies (gemini-3.1-flash-lite)
            if (smartReplies.isNotEmpty()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(smartReplies) { reply ->
                        SuggestionChip(
                            onClick = {
                                scope.launch {
                                    socialRepository.sendMessage(
                                        conversationId = conversationId,
                                        senderId = currentUser?.id ?: "me",
                                        senderName = currentUser?.displayName ?: "Me",
                                        senderAvatarId = currentUser?.avatarId ?: "char_explorer",
                                        text = reply
                                    )
                                }
                            },
                            label = { Text(reply, style = MaterialTheme.typography.bodySmall) }
                        )
                    }
                }
            }

            // Message Composer Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Attach live location button
                IconButton(
                    onClick = {
                        val lat = currentUser?.latitude ?: 37.7749
                        val lng = currentUser?.longitude ?: -122.4194
                        scope.launch {
                            socialRepository.sendMessage(
                                conversationId = conversationId,
                                senderId = currentUser?.id ?: "me",
                                senderName = currentUser?.displayName ?: "Me",
                                senderAvatarId = currentUser?.avatarId ?: "char_explorer",
                                text = "Shared live pin",
                                messageType = "LOCATION",
                                lat = lat,
                                lng = lng,
                                placeName = "Current Coordinates: ${String.format("%.4f", lat)}, ${String.format("%.4f", lng)}"
                            )
                        }
                    },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddLocationAlt,
                        contentDescription = "Share Location Pin",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Message...") },
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp)
                )

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            val msgToSend = inputText
                            inputText = ""
                            scope.launch {
                                socialRepository.sendMessage(
                                    conversationId = conversationId,
                                    senderId = currentUser?.id ?: "me",
                                    senderName = currentUser?.displayName ?: "Me",
                                    senderAvatarId = currentUser?.avatarId ?: "char_explorer",
                                    text = msgToSend
                                )
                            }
                        }
                    },
                    enabled = inputText.isNotBlank(),
                    colors = IconButtonDefaults.iconButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "Send")
                }
            }
        }
    }
}

@Composable
fun CreateGroupDialog(
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var title by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Private Group") },
        text = {
            Column {
                Text(
                    "Create a private group for your trusted circle to chat and view live routes together.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Group Name") },
                    placeholder = { Text("e.g. Weekend Cycling Squad") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (title.isNotBlank()) onCreate(title) },
                enabled = title.isNotBlank()
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
