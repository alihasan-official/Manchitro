package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AtlasForestGreenDark,
    onPrimary = Color(0xFF00382A),
    primaryContainer = AtlasForestSoftDark,
    onPrimaryContainer = AtlasForestGreenPressedDark,
    secondary = AtlasTextSecondaryDark,
    onSecondary = AtlasBgDark,
    background = AtlasBgDark,
    onBackground = AtlasTextPrimaryDark,
    surface = AtlasSurfaceDark,
    onSurface = AtlasTextPrimaryDark,
    surfaceVariant = AtlasSurfaceVariantDark,
    onSurfaceVariant = AtlasTextSecondaryDark,
    outline = AtlasBorderDark,
    error = AtlasError,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = AtlasForestGreenLight,
    onPrimary = Color.White,
    primaryContainer = AtlasForestSoftLight,
    onPrimaryContainer = AtlasForestGreenPressedLight,
    secondary = AtlasTextSecondaryLight,
    onSecondary = Color.White,
    background = AtlasBgLight,
    onBackground = AtlasTextPrimaryLight,
    surface = AtlasSurfaceLight,
    onSurface = AtlasTextPrimaryLight,
    surfaceVariant = AtlasSurfaceVariantLight,
    onSurfaceVariant = AtlasTextSecondaryLight,
    outline = AtlasBorderLight,
    error = AtlasError,
    onError = Color.White
)

@Composable
fun AtlasTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to preserve brand Atlas cartographic palette
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
