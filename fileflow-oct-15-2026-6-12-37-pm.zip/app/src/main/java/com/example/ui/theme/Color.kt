package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Project Atlas Theme Colors
val AtlasForestGreenLight = Color(0xFF4B7F70)
val AtlasForestGreenPressedLight = Color(0xFF39695C)
val AtlasForestSoftLight = Color(0xFFE0EEE8)
val AtlasBgLight = Color(0xFFF6F7F5)
val AtlasSurfaceLight = Color(0xFFFFFFFF)
val AtlasSurfaceVariantLight = Color(0xFFEEF1EE)
val AtlasTextPrimaryLight = Color(0xFF202722)
val AtlasTextSecondaryLight = Color(0xFF68736D)
val AtlasBorderLight = Color(0xFFE2E7E2)

val AtlasForestGreenDark = Color(0xFF8DC8B2)
val AtlasForestGreenPressedDark = Color(0xFFA5D8C5)
val AtlasForestSoftDark = Color(0xFF243B32)
val AtlasBgDark = Color(0xFF111614)
val AtlasSurfaceDark = Color(0xFF191F1C)
val AtlasSurfaceVariantDark = Color(0xFF232B26)
val AtlasTextPrimaryDark = Color(0xFFF0F4F0)
val AtlasTextSecondaryDark = Color(0xFFA5B0A8)
val AtlasBorderDark = Color(0xFF303A33)

val AtlasSuccess = Color(0xFF26836A)
val AtlasWarning = Color(0xFFB7792D)
val AtlasError = Color(0xFFC44F55)

// Map-specific cartographic tones
val MapWaterLight = Color(0xFFDDEAEF)
val MapParkLight = Color(0xFFE2EBDD)
val MapRoadLight = Color(0xFFFFFFFF)
val MapBuildingLight = Color(0xFFECEFEA)

val MapWaterDark = Color(0xFF16232B)
val MapParkDark = Color(0xFF18261F)
val MapRoadDark = Color(0xFF242C27)
val MapBuildingDark = Color(0xFF1B221E)
