package com.example

import android.app.Application
import com.example.data.local.AtlasDatabase
import com.example.data.local.SessionManager
import com.example.data.repository.AuthRepository
import com.example.data.repository.GeminiRepository
import com.example.data.repository.SocialRepository

class AtlasApplication : Application() {
    lateinit var database: AtlasDatabase
        private set
    lateinit var sessionManager: SessionManager
        private set
    lateinit var authRepository: AuthRepository
        private set
    lateinit var socialRepository: SocialRepository
        private set
    lateinit var geminiRepository: GeminiRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = AtlasDatabase.getDatabase(this)
        sessionManager = SessionManager(this)
        authRepository = AuthRepository(database.atlasDao(), sessionManager)
        socialRepository = SocialRepository(database.atlasDao())
        geminiRepository = GeminiRepository()
    }

    companion object {
        lateinit var instance: AtlasApplication
            private set
    }
}
