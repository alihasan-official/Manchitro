package com.example.model

import androidx.compose.ui.graphics.Color

data class AvatarOption(
    val id: String,
    val name: String,
    val category: String, // "Character", "Vehicle", "Animal", "Abstract"
    val iconEmoji: String, // fallback / visual indicator
    val accentColor: Color,
    val description: String
)

object AvatarCatalog {
    val characterAvatars = listOf(
        AvatarOption("char_explorer", "Atlas Explorer", "Character", "🧭", Color(0xFF4B7F70), "Urban trailblazer"),
        AvatarOption("char_runner", "Night Runner", "Character", "🏃", Color(0xFFE27D60), "Always on the move"),
        AvatarOption("char_pilot", "Aero Pilot", "Character", "👨‍✈️", Color(0xFF41B3A3), "High altitude navigator"),
        AvatarOption("char_wanderer", "Nomad", "Character", "🎒", Color(0xFF8D6E63), "Off-grid explorer"),
        AvatarOption("char_cosmonaut", "Stargazer", "Character", "👨‍🚀", Color(0xFF5C6BC0), "Cosmic wanderer"),
        AvatarOption("char_fox", "Shadow Fox", "Animal", "🦊", Color(0xFFFF7043), "Swift and quiet"),
        AvatarOption("char_owl", "Night Owl", "Animal", "🦉", Color(0xFF78909C), "Vigilant guardian"),
        AvatarOption("char_wolf", "Timber Wolf", "Animal", "🐺", Color(0xFF607D8B), "Loyal pack member")
    )

    val vehicleAvatars = listOf(
        AvatarOption("veh_car", "Sports Coupe", "Vehicle", "🏎️", Color(0xFFE53935), "Fast cruiser"),
        AvatarOption("veh_ev", "Electric Hatch", "Vehicle", "🚗", Color(0xFF00ACC1), "Silent daily driver"),
        AvatarOption("veh_bike", "Gravel Bicycle", "Vehicle", "🚲", Color(0xFF43A047), "Pedal-powered"),
        AvatarOption("veh_scooter", "Metro Scooter", "Vehicle", "🛵", Color(0xFFFB8C00), "City lane filterer"),
        AvatarOption("veh_motorcycle", "Street Cruiser", "Vehicle", "🏍️", Color(0xFF6D4C41), "Open highway"),
        AvatarOption("veh_train", "Express Rail", "Vehicle", "🚆", Color(0xFF3949AB), "Commuter transit"),
        AvatarOption("veh_bus", "Tour Bus", "Vehicle", "🚌", Color(0xFFFFB300), "Squad transport"),
        AvatarOption("veh_walk", "Pedestrian", "Vehicle", "🚶", Color(0xFF26A69A), "On foot pacing")
    )

    fun getAvatar(id: String): AvatarOption {
        return (characterAvatars + vehicleAvatars).firstOrNull { it.id == id }
            ?: characterAvatars.first()
    }
}
