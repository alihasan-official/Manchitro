package com.example.model

data class User(
    val id: String,
    val email: String,
    val username: String,
    val displayName: String,
    val bio: String,
    val avatarId: String,
    val vehicleId: String,
    val latitude: Double,
    val longitude: Double,
    val isSharingLocation: Boolean,
    val isGuest: Boolean,
    val phoneNumber: String = ""
)
