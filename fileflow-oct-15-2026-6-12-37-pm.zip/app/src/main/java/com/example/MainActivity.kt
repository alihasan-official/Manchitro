package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.auth.AuthViewModel
import com.example.ui.map.MapViewModel
import com.example.ui.navigation.AtlasApp
import com.example.ui.theme.AtlasTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val app = AtlasApplication.instance
            val authViewModel: AuthViewModel = viewModel {
                AuthViewModel(app.authRepository)
            }
            val mapViewModel: MapViewModel = viewModel {
                MapViewModel(
                    authRepository = app.authRepository,
                    socialRepository = app.socialRepository,
                    sessionManager = app.sessionManager,
                    geminiRepository = app.geminiRepository
                )
            }

            // Location permission launcher
            val locationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { permissions ->
                val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
                val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
                if (fineGranted || coarseGranted) {
                    mapViewModel.centerOnUser()
                }
            }

            LaunchedEffect(Unit) {
                locationPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }

            AtlasTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AtlasApp(
                        authViewModel = authViewModel,
                        mapViewModel = mapViewModel
                    )
                }
            }
        }
    }
}
