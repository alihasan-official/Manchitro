package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "atlas_session_prefs")

class SessionManager(private val context: Context) {
    companion object {
        val KEY_USER_ID = stringPreferencesKey("user_id")
        val KEY_USER_EMAIL = stringPreferencesKey("user_email")
        val KEY_IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        val KEY_MAP_STYLE = stringPreferencesKey("map_style")
        val KEY_SHARING_ENABLED = booleanPreferencesKey("sharing_enabled")
        val KEY_GUEST_MODE = booleanPreferencesKey("guest_mode")
    }

    val currentUserIdFlow: Flow<String?> = context.dataStore.data.map { it[KEY_USER_ID] }
    val isLoggedInFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_IS_LOGGED_IN] ?: false }
    val mapStyleFlow: Flow<String> = context.dataStore.data.map { it[KEY_MAP_STYLE] ?: "SOFT_LIGHT" }
    val sharingEnabledFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_SHARING_ENABLED] ?: true }
    val isGuestModeFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_GUEST_MODE] ?: false }

    suspend fun saveSession(userId: String, email: String, isGuest: Boolean = false) {
        context.dataStore.edit { prefs ->
            prefs[KEY_USER_ID] = userId
            prefs[KEY_USER_EMAIL] = email
            prefs[KEY_IS_LOGGED_IN] = true
            prefs[KEY_GUEST_MODE] = isGuest
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { prefs ->
            prefs.remove(KEY_USER_ID)
            prefs.remove(KEY_USER_EMAIL)
            prefs[KEY_IS_LOGGED_IN] = false
            prefs[KEY_GUEST_MODE] = false
        }
    }

    suspend fun setMapStyle(style: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MAP_STYLE] = style
        }
    }

    suspend fun setSharingEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_SHARING_ENABLED] = enabled
        }
    }
}
