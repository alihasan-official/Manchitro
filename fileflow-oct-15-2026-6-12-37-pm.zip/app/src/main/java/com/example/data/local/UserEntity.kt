package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val id: String,
    val email: String,
    val passwordHash: String,
    val salt: String,
    val username: String,
    val normalizedUsername: String,
    val displayName: String,
    val bio: String,
    val avatarId: String,
    val vehicleId: String,
    val latitude: Double,
    val longitude: Double,
    val lastUpdated: Long,
    val isSharingLocation: Boolean = true,
    val isGuest: Boolean = false,
    val phoneNumber: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
