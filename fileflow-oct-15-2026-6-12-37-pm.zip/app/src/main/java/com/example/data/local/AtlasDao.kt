package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AtlasDao {
    // --- User & Auth ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(normalizedUsername) = LOWER(:username) LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE REPLACE(REPLACE(REPLACE(phoneNumber, ' ', ''), '-', ''), '+', '') = :cleanPhone LIMIT 1")
    suspend fun getUserByPhone(cleanPhone: String): UserEntity?

    @Query("UPDATE users SET phoneNumber = :phone WHERE id = :userId")
    suspend fun updateUserPhone(userId: String, phone: String)

    @Query("UPDATE users SET latitude = :lat, longitude = :lng, lastUpdated = :timestamp WHERE id = :userId")
    suspend fun updateUserLocation(userId: String, lat: Double, lng: Double, timestamp: Long)

    @Query("UPDATE users SET isSharingLocation = :isSharing WHERE id = :userId")
    suspend fun updateLocationSharing(userId: String, isSharing: Boolean)

    @Query("UPDATE users SET avatarId = :avatarId, vehicleId = :vehicleId WHERE id = :userId")
    suspend fun updateUserAvatars(userId: String, avatarId: String, vehicleId: String)

    @Query("DELETE FROM users WHERE id = :userId")
    suspend fun deleteUser(userId: String)

    // --- Friendships & Social Map ---
    @Query("SELECT * FROM friendships WHERE userId = :userId AND status = 'ACCEPTED'")
    fun getAcceptedFriendsFlow(userId: String): Flow<List<FriendshipEntity>>

    @Query("SELECT * FROM friendships WHERE userId = :userId AND status = 'ACCEPTED'")
    suspend fun getAcceptedFriends(userId: String): List<FriendshipEntity>

    @Query("SELECT * FROM friendships WHERE userId = :userId AND status LIKE 'PENDING%'")
    fun getPendingRequestsFlow(userId: String): Flow<List<FriendshipEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriendship(friendship: FriendshipEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriendships(friendships: List<FriendshipEntity>)

    @Query("UPDATE friendships SET status = :status WHERE id = :friendshipId")
    suspend fun updateFriendshipStatus(friendshipId: String, status: String)

    @Query("DELETE FROM friendships WHERE id = :friendshipId")
    suspend fun deleteFriendship(friendshipId: String)

    @Query("UPDATE friendships SET latitude = :lat, longitude = :lng, bearing = :bearing, speed = :speed, lastUpdated = :lastUpdated WHERE friendId = :friendId")
    suspend fun updateFriendLocation(friendId: String, lat: Double, lng: Double, bearing: Float, speed: Float, lastUpdated: Long)

    // --- Messaging ---
    @Query("SELECT * FROM conversations ORDER BY lastMessageTimestamp DESC")
    fun getConversationsFlow(): Flow<List<ConversationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity)

    @Query("SELECT * FROM messages WHERE conversationId = :convId ORDER BY timestamp ASC")
    fun getMessagesForConversation(convId: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query("UPDATE conversations SET lastMessageText = :text, lastMessageTimestamp = :timestamp WHERE id = :convId")
    suspend fun updateConversationLastMessage(convId: String, text: String, timestamp: Long)

    // --- Stories ---
    @Query("SELECT * FROM stories WHERE expiresAt > :now ORDER BY createdAt DESC")
    fun getActiveStoriesFlow(now: Long = System.currentTimeMillis()): Flow<List<StoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity)

    @Query("UPDATE stories SET isViewed = 1 WHERE id = :storyId")
    suspend fun markStoryViewed(storyId: String)

    @Query("DELETE FROM stories WHERE expiresAt <= :now")
    suspend fun purgeExpiredStories(now: Long = System.currentTimeMillis())

    // --- Routes ---
    @Query("SELECT * FROM routes WHERE isActive = 1 ORDER BY startedAt DESC")
    fun getActiveRoutesFlow(): Flow<List<RouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoute(route: RouteEntity)

    @Query("UPDATE routes SET isActive = 0, endedAt = :now WHERE id = :routeId")
    suspend fun stopRoute(routeId: String, now: Long = System.currentTimeMillis())
}
