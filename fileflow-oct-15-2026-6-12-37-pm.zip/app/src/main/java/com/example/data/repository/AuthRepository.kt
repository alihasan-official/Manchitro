package com.example.data.repository

import android.util.Patterns
import com.example.data.local.AtlasDao
import com.example.data.local.FriendshipEntity
import com.example.data.local.MessageEntity
import com.example.data.local.ConversationEntity
import com.example.data.local.SessionManager
import com.example.data.local.StoryEntity
import com.example.data.local.UserEntity
import com.example.data.security.PasswordHasher
import com.example.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.util.UUID

sealed class AuthResult {
    data class Success(val user: User) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository(
    private val dao: AtlasDao,
    private val sessionManager: SessionManager
) {
    val currentUserIdFlow: Flow<String?> = sessionManager.currentUserIdFlow
    val isLoggedInFlow: Flow<Boolean> = sessionManager.isLoggedInFlow
    val isGuestModeFlow: Flow<Boolean> = sessionManager.isGuestModeFlow

    suspend fun getLoggedInUser(): User? {
        val id = sessionManager.currentUserIdFlow.firstOrNull() ?: return null
        return dao.getUserById(id)?.toDomain()
    }

    suspend fun signUp(
        email: String,
        username: String,
        displayName: String,
        password: String,
        phoneNumber: String = ""
    ): AuthResult {
        val cleanEmail = email.trim()
        val cleanUsername = username.trim()
        val cleanDisplayName = displayName.trim().ifEmpty { cleanUsername }
        val cleanPhone = phoneNumber.trim()

        if (cleanEmail.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            return AuthResult.Error("Please enter a valid email address.")
        }
        if (cleanUsername.length < 3) {
            return AuthResult.Error("Username must be at least 3 characters.")
        }
        if (cleanUsername.contains(" ")) {
            return AuthResult.Error("Username cannot contain spaces.")
        }
        if (password.length < 6) {
            return AuthResult.Error("Password must be at least 6 characters.")
        }

        // Check if email already registered
        val existingEmail = dao.getUserByEmail(cleanEmail)
        if (existingEmail != null) {
            return AuthResult.Error("An account with this email already exists.")
        }

        // Check if username already taken
        val normalized = cleanUsername.lowercase()
        val existingUsername = dao.getUserByUsername(normalized)
        if (existingUsername != null) {
            return AuthResult.Error("Username '$cleanUsername' is already taken.")
        }

        val salt = PasswordHasher.generateSalt()
        val passwordHash = PasswordHasher.hashPassword(password, salt)
        val userId = UUID.randomUUID().toString()

        val newUser = UserEntity(
            id = userId,
            email = cleanEmail,
            passwordHash = passwordHash,
            salt = salt,
            username = cleanUsername,
            normalizedUsername = normalized,
            displayName = cleanDisplayName,
            bio = "Exploring the world with Atlas",
            avatarId = "char_explorer",
            vehicleId = "veh_ev",
            latitude = 37.7749, // San Francisco default center
            longitude = -122.4194,
            lastUpdated = System.currentTimeMillis(),
            isSharingLocation = true,
            isGuest = false,
            phoneNumber = cleanPhone
        )

        dao.insertUser(newUser)
        seedInitialFriendsAndContent(userId)
        sessionManager.saveSession(userId, cleanEmail, isGuest = false)

        return AuthResult.Success(newUser.toDomain())
    }

    suspend fun signIn(email: String, password: String): AuthResult {
        val cleanEmail = email.trim()
        if (cleanEmail.isEmpty() || password.isEmpty()) {
            return AuthResult.Error("Please enter both email and password.")
        }

        val user = dao.getUserByEmail(cleanEmail)
            ?: return AuthResult.Error("No account found with this email.")

        val isValid = PasswordHasher.verifyPassword(password, user.salt, user.passwordHash)
        if (!isValid) {
            return AuthResult.Error("Incorrect password. Please try again.")
        }

        sessionManager.saveSession(user.id, user.email, isGuest = user.isGuest)
        return AuthResult.Success(user.toDomain())
    }

    suspend fun signInAsGuest(): AuthResult {
        val guestId = "guest_${UUID.randomUUID().toString().take(8)}"
        val guestEmail = "guest@atlas.app"
        val guestUser = UserEntity(
            id = guestId,
            email = guestEmail,
            passwordHash = "",
            salt = "",
            username = "Explorer_${guestId.takeLast(4)}",
            normalizedUsername = "explorer_${guestId.takeLast(4)}",
            displayName = "Guest Explorer",
            bio = "Exploring Atlas in preview mode",
            avatarId = "char_wanderer",
            vehicleId = "veh_bike",
            latitude = 37.7749,
            longitude = -122.4194,
            lastUpdated = System.currentTimeMillis(),
            isSharingLocation = true,
            isGuest = true
        )

        dao.insertUser(guestUser)
        seedInitialFriendsAndContent(guestId)
        sessionManager.saveSession(guestId, guestEmail, isGuest = true)
        return AuthResult.Success(guestUser.toDomain())
    }

    suspend fun signOut() {
        sessionManager.clearSession()
    }

    suspend fun deleteAccount(): Boolean {
        val userId = sessionManager.currentUserIdFlow.firstOrNull() ?: return false
        dao.deleteUser(userId)
        sessionManager.clearSession()
        return true
    }

    suspend fun updateLocationSharing(enabled: Boolean) {
        val userId = sessionManager.currentUserIdFlow.firstOrNull() ?: return
        dao.updateLocationSharing(userId, enabled)
        sessionManager.setSharingEnabled(enabled)
    }

    suspend fun updateAvatars(avatarId: String, vehicleId: String) {
        val userId = sessionManager.currentUserIdFlow.firstOrNull() ?: return
        dao.updateUserAvatars(userId, avatarId, vehicleId)
    }

    private suspend fun seedInitialFriendsAndContent(userId: String) {
        val now = System.currentTimeMillis()
        val friends = listOf(
            FriendshipEntity(
                id = "${userId}_maya",
                userId = userId,
                friendId = "friend_maya",
                friendUsername = "maya_sun",
                friendDisplayName = "Maya Lin",
                friendAvatarId = "char_runner",
                friendVehicleId = "veh_bike",
                status = "ACCEPTED",
                latitude = 37.7833,
                longitude = -122.4167,
                bearing = 45f,
                speed = 4.2f,
                lastUpdated = now - 120_000,
                isLiveSharing = true,
                batteryLevel = 92,
                statusMessage = "Biking near Ferry Building 🚲",
                friendPhoneNumber = "+1 (415) 555-0192"
            ),
            FriendshipEntity(
                id = "${userId}_liam",
                userId = userId,
                friendId = "friend_liam",
                friendUsername = "liam_tech",
                friendDisplayName = "Liam Vance",
                friendAvatarId = "char_pilot",
                friendVehicleId = "veh_car",
                status = "ACCEPTED",
                latitude = 37.7690,
                longitude = -122.4467,
                bearing = 120f,
                speed = 11.5f,
                lastUpdated = now - 340_000,
                isLiveSharing = true,
                batteryLevel = 68,
                statusMessage = "Heading to Haight-Ashbury ☕",
                friendPhoneNumber = "+1 (415) 555-0143"
            ),
            FriendshipEntity(
                id = "${userId}_chloe",
                userId = userId,
                friendId = "friend_chloe",
                friendUsername = "chloe_art",
                friendDisplayName = "Chloe Chen",
                friendAvatarId = "char_fox",
                friendVehicleId = "veh_scooter",
                status = "ACCEPTED",
                latitude = 37.7600,
                longitude = -122.4200,
                bearing = 270f,
                speed = 0f,
                lastUpdated = now - 60_000,
                isLiveSharing = true,
                batteryLevel = 84,
                statusMessage = "Dolores Park chilling 🌳",
                friendPhoneNumber = "+1 (415) 555-0188"
            ),
            FriendshipEntity(
                id = "${userId}_alex",
                userId = userId,
                friendId = "friend_alex",
                friendUsername = "alex_rover",
                friendDisplayName = "Alex Rivers",
                friendAvatarId = "char_wanderer",
                friendVehicleId = "veh_walk",
                status = "PENDING_INCOMING",
                latitude = 37.7890,
                longitude = -122.4010,
                bearing = 0f,
                speed = 1.1f,
                lastUpdated = now - 900_000,
                isLiveSharing = false,
                batteryLevel = 45,
                statusMessage = "Exploring Union Square",
                friendPhoneNumber = "+1 (415) 555-0171"
            )
        )
        dao.insertFriendships(friends)

        // Seed conversations and welcome messages
        val convMaya = ConversationEntity(
            id = "conv_maya",
            title = "Maya Lin",
            avatarId = "char_runner",
            isGroup = false,
            participantIds = "$userId,friend_maya",
            lastMessageText = "Are we still meeting at Blue Bottle?",
            lastMessageTimestamp = now - 180_000,
            unreadCount = 1
        )
        val convSquad = ConversationEntity(
            id = "conv_squad",
            title = "Weekend Trail Pack 🌲",
            avatarId = "veh_bus",
            isGroup = true,
            participantIds = "$userId,friend_maya,friend_liam,friend_chloe",
            lastMessageText = "Chloe: Dolores Park is gorgeous right now!",
            lastMessageTimestamp = now - 60_000,
            unreadCount = 2
        )
        dao.insertConversation(convMaya)
        dao.insertConversation(convSquad)

        dao.insertMessage(
            MessageEntity(
                id = "msg_1",
                conversationId = "conv_maya",
                senderId = "friend_maya",
                senderName = "Maya Lin",
                senderAvatarId = "char_runner",
                messageType = "TEXT",
                content = "Hey! Check out my live route on the map, cycling your way!",
                timestamp = now - 300_000,
                isMine = false
            )
        )
        dao.insertMessage(
            MessageEntity(
                id = "msg_2",
                conversationId = "conv_maya",
                senderId = "friend_maya",
                senderName = "Maya Lin",
                senderAvatarId = "char_runner",
                messageType = "LOCATION",
                content = "Live Location Preview",
                latitude = 37.7833,
                longitude = -122.4167,
                placeName = "Ferry Building Embarcadero",
                timestamp = now - 240_000,
                isMine = false
            )
        )
        dao.insertMessage(
            MessageEntity(
                id = "msg_3",
                conversationId = "conv_maya",
                senderId = "friend_maya",
                senderName = "Maya Lin",
                senderAvatarId = "char_runner",
                messageType = "TEXT",
                content = "Are we still meeting at Blue Bottle?",
                timestamp = now - 180_000,
                isMine = false,
                isRead = false
            )
        )

        // Seed 24h stories
        dao.insertStory(
            StoryEntity(
                id = "story_maya",
                authorId = "friend_maya",
                authorName = "Maya Lin",
                authorAvatarId = "char_runner",
                mediaType = "TEXT",
                content = "Morning coastal ride done! 32km against the sea breeze 🚴‍♀️🌊",
                caption = "Morning sprint across Embarcadero",
                locationLabel = "Embarcadero Waterfront",
                latitude = 37.7955,
                longitude = -122.3937,
                createdAt = now - 3600_000,
                expiresAt = now + 82800_000
            )
        )
        dao.insertStory(
            StoryEntity(
                id = "story_chloe",
                authorId = "friend_chloe",
                authorName = "Chloe Chen",
                authorAvatarId = "char_fox",
                mediaType = "TEXT",
                content = "Sunbathing at Dolores with matcha latte ☀️🍵 Come find me!",
                caption = "Sunny vibes",
                locationLabel = "Mission Dolores Park",
                latitude = 37.7596,
                longitude = -122.4269,
                createdAt = now - 7200_000,
                expiresAt = now + 79200_000
            )
        )
    }

    suspend fun updatePhoneNumber(phone: String) {
        val userId = sessionManager.currentUserIdFlow.firstOrNull() ?: return
        dao.updateUserPhone(userId, phone)
    }

    private fun UserEntity.toDomain() = User(
        id = id,
        email = email,
        username = username,
        displayName = displayName,
        bio = bio,
        avatarId = avatarId,
        vehicleId = vehicleId,
        latitude = latitude,
        longitude = longitude,
        isSharingLocation = isSharingLocation,
        isGuest = isGuest,
        phoneNumber = phoneNumber
    )
}
