package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "friendships")
data class FriendshipEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val friendId: String,
    val friendUsername: String,
    val friendDisplayName: String,
    val friendAvatarId: String,
    val friendVehicleId: String,
    val status: String, // "ACCEPTED", "PENDING_INCOMING", "PENDING_OUTGOING", "BLOCKED"
    val latitude: Double,
    val longitude: Double,
    val bearing: Float,
    val speed: Float,
    val lastUpdated: Long,
    val isLiveSharing: Boolean = true,
    val batteryLevel: Int = 85,
    val statusMessage: String = "Active now",
    val friendPhoneNumber: String = ""
)
