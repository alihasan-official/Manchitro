package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        FriendshipEntity::class,
        MessageEntity::class,
        ConversationEntity::class,
        StoryEntity::class,
        RouteEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AtlasDatabase : RoomDatabase() {
    abstract fun atlasDao(): AtlasDao

    companion object {
        @Volatile
        private var INSTANCE: AtlasDatabase? = null

        fun getDatabase(context: Context): AtlasDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AtlasDatabase::class.java,
                    "atlas_database"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
