package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey
    val id: String,
    val authorId: String,
    val authorName: String,
    val authorAvatarId: String,
    val mediaType: String, // "TEXT", "IMAGE", "LOCATION_PING"
    val content: String,
    val caption: String,
    val locationLabel: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 86400000L, // 24 hours
    val isViewed: Boolean = false
)

@Entity(tableName = "routes")
data class RouteEntity(
    @PrimaryKey
    val id: String,
    val ownerId: String,
    val ownerName: String,
    val title: String,
    val startLatitude: Double,
    val startLongitude: Double,
    val endLatitude: Double,
    val endLongitude: Double,
    val waypointsJson: String, // JSON array of lat,lng
    val distanceKm: Double,
    val durationMinutes: Int,
    val isActive: Boolean = true,
    val startedAt: Long = System.currentTimeMillis(),
    val endedAt: Long? = null
)
