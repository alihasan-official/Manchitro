package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey
    val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val senderAvatarId: String,
    val messageType: String, // "TEXT", "LOCATION", "STORY_REPLY", "AI_SUGGESTION"
    val content: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val placeName: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isMine: Boolean,
    val isRead: Boolean = true
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val avatarId: String,
    val isGroup: Boolean,
    val participantIds: String, // comma separated
    val lastMessageText: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int = 0
)
