package com.example.data.repository

import com.example.data.local.AtlasDao
import com.example.data.local.ConversationEntity
import com.example.data.local.FriendshipEntity
import com.example.data.local.MessageEntity
import com.example.data.local.RouteEntity
import com.example.data.local.StoryEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class SocialRepository(
    private val dao: AtlasDao
) {
    fun getFriendsFlow(userId: String): Flow<List<FriendshipEntity>> =
        dao.getAcceptedFriendsFlow(userId)

    fun getPendingRequestsFlow(userId: String): Flow<List<FriendshipEntity>> =
        dao.getPendingRequestsFlow(userId)

    suspend fun sendFriendRequest(userId: String, targetIdentifier: String): Boolean {
        val cleanInput = targetIdentifier.trim().removePrefix("@")
        val cleanPhoneDigits = cleanInput.filter { it.isDigit() }

        // Look up by phone if digits exist, otherwise or additionally by username
        val targetByPhone = if (cleanPhoneDigits.length >= 7) dao.getUserByPhone(cleanPhoneDigits) else null
        val targetByUsername = dao.getUserByUsername(cleanInput.lowercase())
        val target = targetByPhone ?: targetByUsername

        val isPhone = cleanPhoneDigits.length >= 7 && (cleanInput.startsWith("+") || cleanInput.all { it.isDigit() || it == '-' || it == ' ' || it == '(' || it == ')' })
        val friendId = target?.id ?: (if (isPhone) "friend_phone_$cleanPhoneDigits" else "friend_${cleanInput.lowercase()}")
        val username = target?.username ?: (if (isPhone) "user_$cleanPhoneDigits" else cleanInput)
        val displayName = target?.displayName ?: (if (isPhone) "Contact ($cleanInput)" else cleanInput.replaceFirstChar { it.uppercase() })
        val phoneNumber = target?.phoneNumber ?: (if (isPhone) cleanInput else "")

        val request = FriendshipEntity(
            id = "${userId}_$friendId",
            userId = userId,
            friendId = friendId,
            friendUsername = username,
            friendDisplayName = displayName,
            friendAvatarId = "char_runner",
            friendVehicleId = "veh_bike",
            status = "PENDING_OUTGOING",
            latitude = 37.7749 + (Math.random() - 0.5) * 0.05,
            longitude = -122.4194 + (Math.random() - 0.5) * 0.05,
            bearing = (Math.random() * 360).toFloat(),
            speed = 3.5f,
            lastUpdated = System.currentTimeMillis(),
            friendPhoneNumber = phoneNumber,
            statusMessage = if (isPhone) "Connected via Phone Number 📱" else "Active now"
        )
        dao.insertFriendship(request)
        return true
    }

    suspend fun acceptFriendRequest(friendshipId: String) {
        dao.updateFriendshipStatus(friendshipId, "ACCEPTED")
    }

    suspend fun rejectFriendRequest(friendshipId: String) {
        dao.deleteFriendship(friendshipId)
    }

    suspend fun updateUserLocation(userId: String, lat: Double, lng: Double) {
        dao.updateUserLocation(userId, lat, lng, System.currentTimeMillis())
    }

    // --- Messages ---
    fun getConversationsFlow(): Flow<List<ConversationEntity>> =
        dao.getConversationsFlow()

    fun getMessagesFlow(conversationId: String): Flow<List<MessageEntity>> =
        dao.getMessagesForConversation(conversationId)

    suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        senderName: String,
        senderAvatarId: String,
        text: String,
        messageType: String = "TEXT",
        lat: Double? = null,
        lng: Double? = null,
        placeName: String? = null
    ) {
        val now = System.currentTimeMillis()
        val msg = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            senderId = senderId,
            senderName = senderName,
            senderAvatarId = senderAvatarId,
            messageType = messageType,
            content = text,
            latitude = lat,
            longitude = lng,
            placeName = placeName,
            timestamp = now,
            isMine = true
        )
        dao.insertMessage(msg)
        dao.updateConversationLastMessage(conversationId, text, now)
    }

    suspend fun createGroup(
        title: String,
        creatorId: String,
        creatorName: String,
        initialMembers: List<String>
    ): String {
        val groupId = "group_${UUID.randomUUID().toString().take(8)}"
        val conv = ConversationEntity(
            id = groupId,
            title = title,
            avatarId = "veh_bus",
            isGroup = true,
            participantIds = (initialMembers + creatorId).joinToString(","),
            lastMessageText = "$creatorName created the group",
            lastMessageTimestamp = System.currentTimeMillis(),
            unreadCount = 0
        )
        dao.insertConversation(conv)
        return groupId
    }

    // --- Stories ---
    fun getActiveStoriesFlow(): Flow<List<StoryEntity>> =
        dao.getActiveStoriesFlow()

    suspend fun postStory(
        authorId: String,
        authorName: String,
        authorAvatarId: String,
        content: String,
        caption: String,
        locationLabel: String,
        lat: Double? = null,
        lng: Double? = null
    ) {
        val story = StoryEntity(
            id = UUID.randomUUID().toString(),
            authorId = authorId,
            authorName = authorName,
            authorAvatarId = authorAvatarId,
            mediaType = "TEXT",
            content = content,
            caption = caption,
            locationLabel = locationLabel,
            latitude = lat,
            longitude = lng
        )
        dao.insertStory(story)
    }

    suspend fun markStoryViewed(storyId: String) {
        dao.markStoryViewed(storyId)
    }

    // --- Routes ---
    fun getActiveRoutesFlow(): Flow<List<RouteEntity>> =
        dao.getActiveRoutesFlow()

    suspend fun startSharingRoute(
        ownerId: String,
        ownerName: String,
        title: String,
        startLat: Double,
        startLng: Double,
        endLat: Double,
        endLng: Double,
        distanceKm: Double,
        durationMinutes: Int
    ): String {
        val routeId = UUID.randomUUID().toString()
        val route = RouteEntity(
            id = routeId,
            ownerId = ownerId,
            ownerName = ownerName,
            title = title,
            startLatitude = startLat,
            startLongitude = startLng,
            endLatitude = endLat,
            endLongitude = endLng,
            waypointsJson = "[]",
            distanceKm = distanceKm,
            durationMinutes = durationMinutes,
            isActive = true
        )
        dao.insertRoute(route)
        return routeId
    }

    suspend fun stopSharingRoute(routeId: String) {
        dao.stopRoute(routeId)
    }
}
