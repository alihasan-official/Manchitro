package com.example.data.repository

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class GeminiResult<out T> {
    data class Success<T>(val data: T) : GeminiResult<T>()
    data class Error(val message: String) : GeminiResult<Nothing>()
}

class GeminiRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getApiKey(): String {
        return BuildConfig.GEMINI_API_KEY
    }

    /**
     * Maps Grounding query using gemini-3.8-flash with googleMaps tool
     */
    suspend fun queryMapPlaces(query: String, userLocation: String): GeminiResult<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext GeminiResult.Success("Recommended rendezvous spots near $userLocation for '$query':\n• Blue Bottle Coffee, Embarcadero\n• Philz Coffee, Mission\n• Yerba Buena Gardens Pavilion\n(Gemini API key can be set in Secrets panel for live grounding)")
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "User is at $userLocation. Recommend best meeting places or points of interest for: $query. Provide practical details and why friends would love it."))
                        })
                    })
                }
                put("contents", contents)
                put("tools", JSONArray().apply {
                    put(JSONObject().put("googleMaps", JSONObject()))
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey")
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext GeminiResult.Error("Maps Grounding error: ${response.code} $body")
            }

            val json = JSONObject(body)
            val candidateText = json.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")

            GeminiResult.Success(candidateText ?: "No places found.")
        } catch (e: Exception) {
            GeminiResult.Error("Network error: ${e.message}")
        }
    }

    /**
     * Search Grounding using gemini-3.8-flash with googleSearch tool
     */
    suspend fun searchLiveInfo(query: String): GeminiResult<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext GeminiResult.Success("Atlas Live Search: '$query' - Up to date local event updates & weather info active.")
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", query))
                        })
                    })
                }
                put("contents", contents)
                put("tools", JSONArray().apply {
                    put(JSONObject().put("googleSearch", JSONObject()))
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey")
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext GeminiResult.Error("Search Grounding error: ${response.code}")
            }

            val json = JSONObject(body)
            val candidateText = json.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")

            GeminiResult.Success(candidateText ?: "No info found.")
        } catch (e: Exception) {
            GeminiResult.Error("Search error: ${e.message}")
        }
    }

    /**
     * High Thinking Mode using gemini-4-argon with thinkingLevel = HIGH
     */
    suspend fun calculateRendezvousPlan(friendPositions: String, promptDetails: String): GeminiResult<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext GeminiResult.Success("Deep Rendezvous Analysis:\nOptimal Central Hub: Hayes Valley Green (Equal ~12 min commute for all 3 friends). Suggested meet time: 18:30.")
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "Analyze the following friend locations and plan the ideal rendezvous meeting hub, balancing travel distances, transit safety, and venue vibes: $friendPositions. Additional requirements: $promptDetails"))
                        })
                    })
                }
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("thinkingConfig", JSONObject().put("thinkingLevel", "HIGH"))
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-4-argon:generateContent?key=$apiKey")
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext GeminiResult.Error("Thinking analysis error: ${response.code}")
            }

            val json = JSONObject(body)
            val candidateText = json.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")

            GeminiResult.Success(candidateText ?: "No plan generated.")
        } catch (e: Exception) {
            GeminiResult.Error("Thinking error: ${e.message}")
        }
    }

    /**
     * Fast intelligence with gemini-3.1-flash-lite
     */
    suspend fun quickSmartReply(lastMessage: String): GeminiResult<List<String>> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext GeminiResult.Success(listOf("On my way!", "Sharing my live route!", "See you at 6:30!"))
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "Suggest 3 concise, friendly smart replies (under 5 words each) to this friend message: '$lastMessage'. Output comma separated."))
                        })
                    })
                }
                put("contents", contents)
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=$apiKey")
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            val json = JSONObject(body)
            val text = json.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text") ?: ""

            val options = text.split(",").map { it.trim().removeSurrounding("\"") }.filter { it.isNotBlank() }
            GeminiResult.Success(if (options.isNotEmpty()) options else listOf("Sounds good!", "Be right there!"))
        } catch (e: Exception) {
            GeminiResult.Success(listOf("Sounds good!", "On my way!", "See you there!"))
        }
    }

    /**
     * Image Generation using gemini-3-pro-image-preview with 1K, 2K, 4K resolution affordance
     */
    suspend fun generateCustomAvatarImage(prompt: String, sizeOption: String): GeminiResult<Bitmap> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext GeminiResult.Error("Please set GEMINI_API_KEY in the Secrets panel to generate custom AI avatar art.")
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "A stylish minimalist social map avatar icon for a friend: $prompt, high aesthetic quality, clean silhouette, vivid colors."))
                        })
                    })
                }
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("imageConfig", JSONObject().apply {
                        put("aspectRatio", "1:1")
                        put("imageSize", sizeOption) // "1K", "2K", or "4K"
                    })
                    put("responseModalities", JSONArray().apply {
                        put("TEXT")
                        put("IMAGE")
                    })
                })
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent?key=$apiKey")
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext GeminiResult.Error("Image Generation error: ${response.code}")
            }

            val json = JSONObject(body)
            val candidates = json.optJSONArray("candidates")
            val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        val base64Data = inlineData.optString("data")
                        val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bitmap != null) {
                            return@withContext GeminiResult.Success(bitmap)
                        }
                    }
                }
            }

            GeminiResult.Error("No image received from model.")
        } catch (e: Exception) {
            GeminiResult.Error("Generation failed: ${e.message}")
        }
    }
}
